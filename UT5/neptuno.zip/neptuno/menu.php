<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <title>Pedidos</title>
    <link rel="stylesheet" href="estilo.css">

  </head>
  <body>
    
        <h1>Gestión de PEDIDOS (NEPTUNO)</h1>
        <h1>Gestión de Pedidos</h1>
    <ul>
        <li><a href="visualizar.php">Visualizar los productos por categoria</a></li>
        <li><a href="eliminar.php">Eliminar un pedido (solo logueados)</a></li>
        <li><a href="modificar.php">Modificar campo cantidad de detallespedidos (solo logueados)</a></li>
        <li><a href="insertar.php">Insertar nuevo pedido (solo logueados)</a></li>
    </ul>
        
        <a href="logout.php">Cerrar Sesion</a>
   
</body>
</html>
