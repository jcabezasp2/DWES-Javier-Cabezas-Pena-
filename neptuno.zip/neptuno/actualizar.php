<link rel="stylesheet" href="css/estilos.css">
<?php
session_start();
include 'conexion.php';
include 'funciones.php';

if(!isset($_SESSION['idCliente']) || $_SESSION['idCliente'] != "HANAR"){
    echo "<P>Acceso SOLO para el usuario HANAR</P>\n";
    echo "<P>[ <A HREF='login.php' TARGET='_top'>Loguearse</A> ]</P>\n";
}else{

    try {
        
        $sql = "SELECT * FROM productos";
        $antiguos = $conexion->prepare($sql);
        $antiguos->execute([]);
    } catch (PDOException $e) {
        echo "ERROR:" . $e->getMessage();
    }

    try{
        $sql = "UPDATE productos SET preciounidad = preciounidad * 1.1";
        $consulta = $conexion->prepare($sql);
        $consulta->execute([]);
    } catch (Exception $e) {
         echo "Fallo: " . $e->getMessage();
    }

    echo '<h1>Actualizar preciounidad de la tabla productos (incrementar un 10%)</h1>';
    echo '<table><tr><th>Producto</th><th>Precio anterior</th><th>Nuevo precio</th></tr>';
    foreach($antiguos as $fila){
        try {
            $sql = "SELECT preciounidad FROM productos WHERE idproducto = :idproducto";
            $consulta = $conexion->prepare($sql);
            $consulta->execute([':idproducto' => $fila['idproducto']]);
            $precioUnidad = $consulta->fetch()['preciounidad'];
        } catch (PDOException $e) {
            echo "ERROR:" . $e->getMessage();
        }
        echo '<tr><td>'.$fila['nombreproducto'].'</td><td>'.$fila['preciounidad'].'</td><td>'.$precioUnidad.'</td></tr>';
    }

    echo '</table>';
}

echo '<p>[<a href="menu.html">Ir al menu</a>]</p>';