<link rel="stylesheet" href="css/estilos.css">
<?php
session_start();
include 'conexion.php';
include 'funciones.php';

if(isset($_POST['enviarPedido'])){
    $_SESSION['idpedido'] = $_POST['pedido'];
}


if(!isset($_SESSION['idCliente'])){
    echo "<P>Acceso SOLO para usuarios logueados</P>\n";
    echo "<P>[ <A HREF='login.php' TARGET='_top'>Loguearse</A> ]</P>\n";
}else{


    $sql = "SELECT * FROM proveedores WHERE idproveedor IN (SELECT DISTINCT idproveedor FROM productos)";
    $consulta = $conexion->prepare($sql);
    $consulta->execute([]);

?>
<div id="datosConexion" >
<p>Usuario <?php echo $_SESSION['idCliente'] ?></p>
<p>hora de la conexion <?php echo $_SESSION['horaConexion'] ?></p>
<p>fecha de la conexion <?php echo $_SESSION['fechaConexion'] ?></p> 
</div>
<h1>Gestión de PEDIDOS (NEPTUNO)</h1>
<h3>INSERTAR UN NUEVO PEDIDO PARA USUARIO LOGUEADO</h3>

<form action="<?php	$_SERVER['PHP_SELF']?>" method="post">
<p>
<label for="idpedido">Idpedido: </label>
<input type="number" name="idpedido" id="idpedido" value="<?php echo isset($_POST['enviar'])? $_POST['idpedido'] : "" ?>" required>
</p>
<p>
    <label for="idcliente">Idcliente: </label>
    <input readonly type="text" name="idcliente" id="idcliente" value="<?php echo $_SESSION['idCliente'] ?>">
</p>
<p>
    <label for="fecha">Fecha para todo: </label>
    <input readonly type="date" name="fecha" id="fecha" value="<?php echo date('Y-m-d', strtotime($_SESSION['fechaConexion'])) ?>">

</p>

<?php
?>
    <button type="submit" name="enviar" value="enviar">Enviar</button>
</form>


<?php
    if(isset($_POST['enviar'])){
        $idpedido = $_POST['idpedido'];
        try{
            $sql = "SELECT idpedido FROM pedidos WHERE idpedido = :idpedido";
            $consulta = $conexion->prepare($sql);
            $consulta->execute([':idpedido'=>$idpedido]);
        } catch (Exception $e) {
             echo "Fallo: " . $e->getMessage();
        }

        if($consulta->rowCount() > 0 ){
            echo "<h3>Pedido ya existente</h3>";
        }else{
            
            $_SESSION['idpedido'] = $idpedido;

            try{
                $sql = "SELECT * FROM productos ";
                $consulta = $conexion->prepare($sql);
                $consulta->execute([]);
            } catch (Exception $e) {
                 echo "Fallo: " . $e->getMessage();
            }


            ?>
            
            <form action="<?php	$_SERVER['PHP_SELF']?>" method="post">

                <table>
                    <tr>
                        <th>idProducto</th>
                        <th>Nombre Producto</th>
                        <th>Precio Unidad</th>
                        <th>UnidadesExistencia</th>
                        <th>Cantidad</th>
                        <th>Seleccionado</th>
                    </tr>
                    
                    <?php

                    foreach($consulta as $fila ){
                        echo "<tr>";
                        echo "<td>". $fila['idproducto']. "</td>";
                        echo "<td>". $fila['nombreproducto']. "</td>";
                        echo "<td>". $fila['preciounidad']. "</td>";
                        echo "<td>". $fila['unidadesexistencia']."</td>";
                        echo "<td><input type='number' name='cantidad[".$fila['idproducto']."]' id='cantidad' min='0' max='".$fila['unidadesexistencia']."'></td>";
                        echo "<td><input type='checkbox'  name='ids[]' value='".$fila['idproducto']."'".mantenerCheckbox('ids', $fila['idproducto'])."></td>";
                    }

                    ?>      


                </table>
                <button type="submit" name="enviar2" value="enviar2">Enviar</button>
            </form>
            <?php

        }
    }

    if(isset($_POST['enviar2'])){
        $totalpedido = 0;
        foreach($_POST['ids'] as $idproducto){
            try {
                $idpedido = $_SESSION['idpedido'];
                $sql = "SELECT preciounidad FROM productos WHERE idproducto = :idproducto";
                $consulta = $conexion->prepare($sql);
                $consulta->execute([':idproducto'=>$idproducto]);
                $preciounidad = $consulta->fetch()['preciounidad'];
                $totalpedido += $_POST['cantidad'][$idproducto] * $preciounidad;
            } catch (PDOException $e) {
                echo "ERROR:" . $e->getMessage();
            }
            
        }
            echo $totalpedido;
            $conexion->beginTransaction();
            try{
                //  Insertar pedidos con el campo totalpedidos que se obtiene sumando 
                // precio*cantidad en cada producto
                $idpedido = $_SESSION['idpedido'];
                $idcliente = $_SESSION['idCliente'];
                $fecha = date('Y-m-d', strtotime($_SESSION['fechaConexion']));

                $sql = "INSERT INTO pedidos (idpedido, idcliente, fechapedido, totalpedido) VALUES (:idpedido, :idcliente, :fechapedido, :totalpedido)";
                $consulta = $conexion->prepare($sql);
                $consulta->execute([':idpedido' => $idpedido, ':idcliente' => $idcliente, ':fechapedido' => $fecha, ':totalpedido' => $totalpedido]);

            foreach($_POST['ids'] as $idproducto){

                //Insertar en detalles de pedidos
                $sql = "SELECT preciounidad FROM productos WHERE idproducto = :idproducto";
                $consulta = $conexion->prepare($sql);
                $consulta->execute([':idproducto'=>$idproducto]);
                $precioUnidad = $consulta->fetch()['preciounidad'];
                $cantidad = $_POST['cantidad'][$idproducto];

                $sql = "INSERT INTO detallesdepedidos VALUES(:idpedido, :idproducto, :preciounidad, :cantidad)";
                $consulta = $conexion->prepare($sql);
                $consulta->execute([':idpedido' => $idpedido, ':idproducto'=>$idproducto, ':preciounidad'=>$precioUnidad, 'cantidad'=>$cantidad]);

                // Actualizar en productos unidadesexistencia
                $sql = "UPDATE productos SET unidadesexistencia = unidadesexistencia - :cantidad WHERE idproducto = :idproducto";
                $consulta = $conexion->prepare($sql);
                $consulta->execute([':cantidad'=>$cantidad, ':idproducto'=>$idproducto]);

            }

                $conexion->commit();
            } catch (Exception $e) {
                $conexion->rollBack();
                echo "Fallo: " . $e->getMessage();
            }
        

    }
    echo '<p>[<a href="logout.php">Desconectar</a>]</p>';
}
?> <p>[<a href="menu.html">Ir al menu</a>]</p> <?php